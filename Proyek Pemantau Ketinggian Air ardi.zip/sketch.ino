#include <WiFi.h>
char* ssid = "Wokwi-GUEST";
char* pass = "";

#define PIN_TRIG 13
#define PIN_ECHO 14
int jarakDasarKeSensor = 100;
int tinggiMukaAir = 0;
int jarak = 0;

#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd (0x27, 16, 2);

void setup() {
  Serial.begin(115200);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  lcd.init();
  lcd.backlight();

  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Connecting...");
  WiFi.begin(ssid, pass);
  while(WiFi.status() != WL_CONNECTED){
    Serial.println(".");
    delay(1000);
  }
  Serial.println("WiFi Connected");
  Serial.println(WiFi.localIP());
  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("Connected!");
  delay(1500);

}

void loop() {

  // Start a new measurement:
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);

  // Read the result:
  int duration = pulseIn(PIN_ECHO, HIGH);
  jarak = duration / 58;
  tinggiMukaAir = jarakDasarKeSensor - jarak;
  Serial.print("Jarak: ");
  Serial.print(jarak);
  Serial.print("  -  Tinggi: ");
  Serial.println(tinggiMukaAir);

  lcd.setCursor(0,0);
  lcd.print("Tinggi Muka Air:");
  lcd.setCursor(0,1);
  lcd.print(String() + tinggiMukaAir + " CM   ");

  delay(1000);
}